create view V_ITEM_TYPE as
  select "ITEM_TYPE","NOTE" from ITEM_TYPE
/

