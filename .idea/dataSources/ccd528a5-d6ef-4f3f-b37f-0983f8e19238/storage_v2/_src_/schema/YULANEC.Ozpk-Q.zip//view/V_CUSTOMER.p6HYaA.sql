create view V_CUSTOMER as
  select "CUSTOMER_CODE","CUSTOMER_NAME","STATUS_ID","CUSTOMER_BELONG" from customer
/

