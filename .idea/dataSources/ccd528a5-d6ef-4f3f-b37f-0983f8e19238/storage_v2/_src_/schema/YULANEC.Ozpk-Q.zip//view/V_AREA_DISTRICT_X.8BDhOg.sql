create view V_AREA_DISTRICT_X as
  select DISTRICT_ID AS ID,DISTRICT_NAME AS NAME from area_district@ERP2EC WHERE parent_district='CN'
    UNION
  select AREA_CODE,AREA_NAME from area_code@ERP2EC where area_name like'11%'or area_name like '%??????%'
    UNION
  select REGION_ID,REGION_NAME FROM AREA_REGION@ERP2EC
/

