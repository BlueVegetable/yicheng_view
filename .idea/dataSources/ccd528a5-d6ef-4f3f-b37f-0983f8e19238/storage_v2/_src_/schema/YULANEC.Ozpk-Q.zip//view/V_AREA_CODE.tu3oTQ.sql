create view V_AREA_CODE as
  select "AREA_BELONG","AREA_CODE","AREA_NAME","LEVEL_NO","USE_ID" from area_code
/

